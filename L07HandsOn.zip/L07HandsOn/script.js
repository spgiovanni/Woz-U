
 function getFullName(){
    let firstName = document.getElementById("firstName");
    let lastName = document.getElementById("lastName");
    let nameRegex = ^A;
    let morThan1Char = [Ab];
    if(firstName && lastname === nameRegex,firstName && lastName >= morThan1Char){
        console.log(firstName +" "+ lastName);
    } else {
        alert("First Name and Last Name should start with a capital letter, and be at least characters in long");
    }
    
}